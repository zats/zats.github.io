declare const MeshGradient: any;
export default MeshGradient;
