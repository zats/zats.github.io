export class Gradient {
    constructor(...t: any[]);
    isLoadedClass: boolean;
    el: any;
    inputColors: any;
    connect(): Promise<void>;
    shaderFiles: {
        vertex: string;
        noise: string;
        blend: string;
        fragment: string;
    } | undefined;
    conf: {
        presetName: string;
        wireframe: boolean;
        density: number[];
        zoom: number;
        rotation: number;
        playing: boolean;
    } | undefined;
    minigl: MiniGl | undefined;
    disconnect(): void;
    setCanvasSize(width: any, height: any, initial?: boolean): void;
    width: any;
    height: any;
    xSegCount: number | undefined;
    ySegCount: number | undefined;
    initMaterial(): any;
    uniforms: {
        u_time: any;
        u_shadow_power: any;
        u_darken_top: any;
        u_active_colors: any;
        u_global: any;
        u_vertDeform: any;
        u_baseColor: any;
        u_waveLayers: any;
    } | undefined;
    vertexShader: string | undefined;
    initMesh(): void;
    material: any;
    geometry: any;
    mesh: any;
    shouldSkipFrame(e: any): true | undefined;
    updateFrequency(e: any): void;
    toggleColor(index: any): void;
    showGradientLegend(): void;
    isGradientLegendVisible: boolean | undefined;
    hideGradientLegend(): void;
    changePosition(val: any): void;
    t: number | undefined;
    init(): void;
    initGradientColors(): void;
    sectionColors: any;
    changeGradientColors(colors: any): void;
    reGenerateCanvas(): void;
    getGradientColors(): any;
}
import { MiniGl } from "./webgl";
