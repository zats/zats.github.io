export function normalizeColor(hexCode: any): number[];
export class MiniGl {
    constructor(canvas: any, width: any, height: any, debug?: boolean);
    canvas: any;
    gl: any;
    meshes: any[];
    debug: (e: any, ...args: any[]) => void;
    commonUniforms: {
        projectionMatrix: any;
        modelViewMatrix: any;
        resolution: any;
        aspectRatio: any;
    };
    setSize(e?: number, t?: number, e1?: number, t1?: number): void;
    width: number | undefined;
    height: number | undefined;
    setOrthographicCamera(e?: number, t?: number, n?: number, i?: number, s?: number): void;
    render(): void;
}
